// secrets.h — DO NOT COMMIT (gitignored)
// Fill in your local WiFi + MQTT broker info here.

#pragma once

#define SECRET_WIFI_SSID      "DragonhispeedUTD"
#define SECRET_WIFI_PASSWORD  "aabbcc112233"

#define SECRET_MQTT_HOST      "10.88.1.69"
#define SECRET_MQTT_PORT      11883
#define SECRET_MQTT_USERNAME  ""
#define SECRET_MQTT_PASSWORD  ""
