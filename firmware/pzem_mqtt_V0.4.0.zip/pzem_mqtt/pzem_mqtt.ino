/*
 * Board-level firmware for LED Wall Monitor — HKL-EA8 (Hankerila)
 *
 * Sensors:
 *   - PZEM-004T v3.0 via HMI port (Serial1, GPIO 15/16, TTL)
 *   - KWS-AC301L via built-in RS485 (Serial2, GPIO 14/13, auto-direction)
 *
 * Publishes board telemetry to MQTT:
 *   sites/<SITE>/boards/<BOARD>/telemetry
 *
 * Payload:
 *   {
 *     "boardCode":"BOARD-001",
 *     "firmware":"v0.2.0",
 *     "ipAddress":"10.88.1.160",
 *     "sensors": {
 *       "PZEM-001": { voltage, current, power, energy, raw:{pf,frequency} },
 *       "KWS-001":  { voltage, current, power, energy, temperature, raw:{pf,frequency} }
 *     }
 *   }
 *
 * Libraries (Arduino Library Manager):
 *   - PZEM004Tv30   by Jakub Mandula
 *   - ModbusMaster  by 4-20ma
 *   - PubSubClient  by Nick O'Leary
 *   - ArduinoJson   by Benoit Blanchon
 */

#include <WiFi.h>
#include <PubSubClient.h>
#include <PZEM004Tv30.h>
#include <ModbusMaster.h>
#include <ArduinoJson.h>
#include "secrets.h"

// Forward declaration so the Arduino auto-prototype generator picks it up.
struct KwsReading {
  bool ok;
  float voltage, current, power, energy, frequency, pf, temperature;
};

// ─── User configuration ─────────────────────────────────────────────
const char* WIFI_SSID         = SECRET_WIFI_SSID;
const char* WIFI_PASSWORD     = SECRET_WIFI_PASSWORD;

const char* MQTT_HOST         = SECRET_MQTT_HOST;
const uint16_t MQTT_PORT      = SECRET_MQTT_PORT;
const char* MQTT_USERNAME     = SECRET_MQTT_USERNAME;
const char* MQTT_PASSWORD     = SECRET_MQTT_PASSWORD;

const char* SITE_CODE         = "SITE-001";
const char* BOARD_CODE        = "BOARD-001";
const char* FIRMWARE_VERSION  = "v0.2.0";

const char* SENSOR_PZEM_CODE  = "PZEM-001";
const char* SENSOR_KWS_CODE   = "KWS-001";
const uint8_t KWS_SLAVE_ADDR  = 2;   // verified by scanner

const uint32_t PUBLISH_INTERVAL_MS = 3000;

// ─── HKL-EA8 (Hankerila) pinout ─────────────────────────────────────
// HMI port: GND, TX(GPIO16), RX(GPIO15), 5V    (PZEM via TTL)
// RS485:    A(GPIO13_TX) / B(GPIO14_RX)        (KWS via RS485)
//
// User wired PZEM TX->HMI 'TX' (straight); we swap pins in software so
// ESP32 listens on GPIO 16 (where PZEM transmits) and transmits on GPIO 15.
#define PZEM_RX_PIN 16
#define PZEM_TX_PIN 15

#define KWS_RX_PIN  14
#define KWS_TX_PIN  13

// ─── Globals ────────────────────────────────────────────────────────
PZEM004Tv30 pzem(Serial1, PZEM_RX_PIN, PZEM_TX_PIN);
ModbusMaster kws;
WiFiClient   wifiClient;
PubSubClient mqtt(wifiClient);

char mqttTopic[128];
char clientId[64];

// ─── Helpers ────────────────────────────────────────────────────────
void connectWiFi() {
  Serial.printf("WiFi: connecting to %s\n", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.printf("\nWiFi: connected, IP=%s\n", WiFi.localIP().toString().c_str());
}

void connectMqtt() {
  while (!mqtt.connected()) {
    Serial.printf("MQTT: connecting to %s:%u as %s\n", MQTT_HOST, MQTT_PORT, clientId);
    bool ok = (strlen(MQTT_USERNAME) > 0)
      ? mqtt.connect(clientId, MQTT_USERNAME, MQTT_PASSWORD)
      : mqtt.connect(clientId);
    if (ok) {
      Serial.println("MQTT: connected");
    } else {
      Serial.printf("MQTT: failed rc=%d, retry in 3s\n", mqtt.state());
      delay(3000);
    }
  }
}

// KWS-AC301L holding-register map (verified empirically against our unit):
//   0x000E      Voltage          / 10   -> V
//   0x000F+0x10 Current Lo+Hi    / 1000 -> A
//   0x0011+0x12 Power   Lo+Hi    / 10   -> W
//   0x0017      Energy           / 1000 -> kWh   (register is in Wh)
//   0x001A      External temp    / 1    -> deg C
//   0x001D      Power factor     / 100
//   0x001E      Frequency        / 10   -> Hz
KwsReading readKws() {
  KwsReading r{};

  // Range A: 0x000E..0x0012 (V/A/W) — 5 regs
  uint8_t result = kws.readHoldingRegisters(0x000E, 5);
  if (result != kws.ku8MBSuccess) {
    Serial.printf("KWS: Modbus error A 0x%02X\n", result);
    r.ok = false;
    return r;
  }
  r.voltage     = kws.getResponseBuffer(0) / 10.0f;
  uint32_t iRaw = ((uint32_t)kws.getResponseBuffer(2) << 16) | kws.getResponseBuffer(1);
  r.current     = iRaw / 1000.0f;
  uint32_t pRaw = ((uint32_t)kws.getResponseBuffer(4) << 16) | kws.getResponseBuffer(3);
  r.power       = pRaw / 10.0f;

  // Range B: 0x0017..0x001E (energy, temp, PF, frequency) — 8 regs
  result = kws.readHoldingRegisters(0x0017, 8);
  if (result != kws.ku8MBSuccess) {
    Serial.printf("KWS: Modbus error B 0x%02X\n", result);
    // partial success - keep V/A/W, leave the rest at 0
    r.ok = true;
    return r;
  }
  r.energy      = kws.getResponseBuffer(0) / 1000.0f;  // register in Wh -> kWh
  int16_t tRaw  = (int16_t)kws.getResponseBuffer(3);   // 0x001A external temp
  r.temperature = tRaw;
  r.pf          = kws.getResponseBuffer(6) / 100.0f;   // 0x001D
  r.frequency   = kws.getResponseBuffer(7) / 10.0f;    // 0x001E

  r.ok = true;
  return r;
}

bool publishReading() {
  // ── Read PZEM ──
  float pV = pzem.voltage();
  bool pzemOk = !isnan(pV);
  float pI    = pzemOk ? pzem.current()   : 0;
  float pP    = pzemOk ? pzem.power()     : 0;
  float pE    = pzemOk ? pzem.energy()    : 0;
  float pFreq = pzemOk ? pzem.frequency() : 0;
  float pPF   = pzemOk ? pzem.pf()        : 0;

  // ── Read KWS ──
  KwsReading kws_r = readKws();

  // ── Pretty print to Serial ──
  Serial.println();
  if (pzemOk) {
    Serial.printf("  %s:  V=%6.1f  I=%6.3f  W=%6.1f  E=%7.3f kWh  PF=%.2f  %.1fHz\n",
                  SENSOR_PZEM_CODE, pV, pI, pP, pE, pPF, pFreq);
  } else {
    Serial.printf("  %s:  no signal\n", SENSOR_PZEM_CODE);
  }
  if (kws_r.ok) {
    Serial.printf("  %s:   V=%6.1f  I=%6.3f  W=%6.1f  E=%7.3f kWh  PF=%.2f  %.1fHz  T=%.1f C\n",
                  SENSOR_KWS_CODE, kws_r.voltage, kws_r.current, kws_r.power,
                  kws_r.energy, kws_r.pf, kws_r.frequency, kws_r.temperature);
  } else {
    Serial.printf("  %s:   no signal\n", SENSOR_KWS_CODE);
  }

  // ── Build payload ──
  StaticJsonDocument<768> doc;
  doc["boardCode"] = BOARD_CODE;
  doc["firmware"]  = FIRMWARE_VERSION;
  doc["ipAddress"] = WiFi.localIP().toString();

  JsonObject sensors = doc.createNestedObject("sensors");

  JsonObject pSensor = sensors.createNestedObject(SENSOR_PZEM_CODE);
  if (pzemOk) {
    pSensor["voltage"]  = pV;
    pSensor["current"]  = pI;
    pSensor["power"]    = pP;
    pSensor["energy"]   = pE;
    JsonObject pRaw = pSensor.createNestedObject("raw");
    pRaw["pf"]        = pPF;
    pRaw["frequency"] = pFreq;
  } else {
    pSensor["error"] = "no_signal";
  }

  JsonObject kSensor = sensors.createNestedObject(SENSOR_KWS_CODE);
  if (kws_r.ok) {
    kSensor["voltage"]     = kws_r.voltage;
    kSensor["current"]     = kws_r.current;
    kSensor["power"]       = kws_r.power;
    kSensor["energy"]      = kws_r.energy;
    kSensor["temperature"] = kws_r.temperature;
    JsonObject kRaw = kSensor.createNestedObject("raw");
    kRaw["pf"]        = kws_r.pf;
    kRaw["frequency"] = kws_r.frequency;
  } else {
    kSensor["error"] = "no_signal";
  }

  char payload[768];
  size_t n = serializeJson(doc, payload, sizeof(payload));

  bool ok = mqtt.publish(mqttTopic, (const uint8_t*)payload, n, false);
  Serial.printf("  MQTT %s (state=%d)  bytes=%u\n", ok ? "OK" : "FAIL", mqtt.state(), (unsigned)n);
  return ok;
}

// ─── Arduino lifecycle ──────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println("\n=== LED-Wall-Monitor board firmware (PZEM + KWS) ===");

  snprintf(mqttTopic, sizeof(mqttTopic),
           "sites/%s/boards/%s/telemetry", SITE_CODE, BOARD_CODE);
  snprintf(clientId, sizeof(clientId), "%s-%06X",
           BOARD_CODE, (uint32_t)ESP.getEfuseMac());

  // RS485 for KWS — built-in transceiver is auto-direction, no DE/RE
  Serial2.begin(9600, SERIAL_8N1, KWS_RX_PIN, KWS_TX_PIN);
  kws.begin(KWS_SLAVE_ADDR, Serial2);

  connectWiFi();

  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  mqtt.setKeepAlive(30);
  mqtt.setBufferSize(1024);
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) connectWiFi();
  if (!mqtt.connected())             connectMqtt();
  mqtt.loop();

  static uint32_t lastPublish = 0;
  if (millis() - lastPublish >= PUBLISH_INTERVAL_MS) {
    lastPublish = millis();
    publishReading();
  }
}
